﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oat_3_exercicio_58
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("QUANTIDADE DE NUMEROS A SEREM LIDOS :");
            int quantidade = int.Parse(Console.ReadLine());

            int[] numeros = new int[quantidade];
            int soma = 0;
            int maior = 0;

            for (int i = 0; i < quantidade; i++)
            {
                Console.WriteLine("DIGITE O NUMERO {0}:", i + 1);
                numeros[i] = int.Parse(Console.ReadLine());

                soma += numeros[i];

                if (numeros[i] > maior)
                {
                    maior = numeros[i];
                }
            }

            double media = (double)soma / quantidade;

            Console.WriteLine(": {0}", media);
            Console.WriteLine("MAIOR NUMERO: {0}", maior);

            Console.ReadLine();

            Console.ReadLine();
        }
    }
}
