﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oat_3_exercicio_29
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int cont = 1;
            while (cont <= 2000)
            {
                Console.WriteLine(cont);
                cont++;
            }

            Console.ReadLine();
        }
    }
}
