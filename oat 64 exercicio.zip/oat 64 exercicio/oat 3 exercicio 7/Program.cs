﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oat_3_ex_7
{
    internal class Program
    {
        static void Main(string[] args)
        {


            Console.Write("INFORME A TEMPERATURA EM GRAUS FAHRENHEIT : ");
            double f = double.Parse(Console.ReadLine());

            double c = (f - 32) * 5 / 9;
            Console.WriteLine("======================================");
            Console.WriteLine("ESSA TEMPERATURA EM GRAUS CELSIUS E " + c);

            Console.ReadLine();
        }
    }
}
