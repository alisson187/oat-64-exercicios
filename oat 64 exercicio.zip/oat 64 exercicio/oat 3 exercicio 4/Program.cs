﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oat_3_exercicio_4
{
    internal class Program
    {
        static void Main(string[] args)
        {


            Console.Write("DIGITE O PRIMEIRO VALOR: ");
            int a = int.Parse(Console.ReadLine());
            Console.Write("DIGITE O SEGUNDO VALOR: ");
            int b = int.Parse(Console.ReadLine());
            Console.Write("DIGITE O TERCEIRO VALOR: ");
            int c = int.Parse(Console.ReadLine());
            Console.Write("DIGITE O QUARTO VALOR: ");
            int d = int.Parse(Console.ReadLine());

            int adiçao = (a + b) + (a + c) + (a + d) + (b + c) + (b + d) + (c + d);
            int multiplicaçao = (a * b) * (a * c) * (a * d) * (b * c) * (b * d) * (c * d);
            Console.WriteLine("A ADIÇAO DESSES VALORES E " + adiçao);
            Console.WriteLine("A MULTIPLICAÇAO DESSES VALORES E " + multiplicaçao);

            Console.ReadLine();
        }
    }
}
