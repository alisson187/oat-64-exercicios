﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oat_3_exercicio_35
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int cont = 1;
            while (cont <= 100)
            {
                Console.WriteLine(cont);
                if (cont % 10 == 0)
                {
                    Console.WriteLine("MULTIPLO DE DEZ");
                }
                cont++;
            }

            Console.ReadLine();
        }
    }
}
