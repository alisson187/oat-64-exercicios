﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oat_3_exercicio_27
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int cacularFatorial = 0;
            Console.WriteLine("QUANTOS NUMEROS DESEJA PROCESSAR :");
            int quantidade = int.Parse(Console.ReadLine());

            for (int i = 1; i <= quantidade; i++)
            {
                Console.WriteLine("INFORME O NUMERO " + i + ":");
                int numero = int.Parse(Console.ReadLine());

                long fatorial = CalcularFatorial(numero);
                Console.WriteLine("O FATORIAL DE " + numero + " E: " + fatorial);
                Console.WriteLine();
            }

        }
    }
}
