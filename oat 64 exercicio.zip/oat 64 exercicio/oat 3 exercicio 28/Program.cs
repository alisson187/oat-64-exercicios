﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oat_3_exercicio_28
{
    internal class Program
    {
        static void Main(string[] args)
        {

            for (int cont = 100; cont <= 200; cont++)
            {
                if (cont % 2 == 1)
                {
                    Console.WriteLine(cont);
                }
            }

            Console.ReadLine();

        }
    }
}
