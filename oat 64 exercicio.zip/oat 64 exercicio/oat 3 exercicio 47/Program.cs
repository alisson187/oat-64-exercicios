﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oat_3_exercicio_47
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int tamanhoVetor = 10;

     
            int[] vetor = new int[tamanhoVetor];

         
            Console.WriteLine("DIGITE OS ELEMENTOS DO VETOR:");
            for (int i = 0; i < tamanhoVetor; i++)
            {
                Console.Write("ELEMENTO {0}: ", i + 1);
                vetor[i] = int.Parse(Console.ReadLine());
            }

         
            Console.Write("DIGITE O NUMERO X: ");
            int numeroX = int.Parse(Console.ReadLine());

 
            int maioresQueX = 0;
            int menoresQueX = 0;
            int iguaisAX = 0;


            for (int i = 0; i < tamanhoVetor; i++)
            {
                if (vetor[i] > numeroX)
                {
                    maioresQueX++;
                }
                else if (vetor[i] < numeroX)
                {
                    menoresQueX++;
                }
                else
                {
                    iguaisAX++;
                }
            }

      
            Console.WriteLine("TOTAL DE NUMEROS MAIORES QUE X: " + maioresQueX);
            Console.WriteLine("TOTAL DE NUMEROS MENORES QUE X: " + menoresQueX);
            Console.WriteLine("TOTAL DE NUMEROS IGUAIS A X: " + iguaisAX);

            Console.ReadLine();
        }
    }

}
    

