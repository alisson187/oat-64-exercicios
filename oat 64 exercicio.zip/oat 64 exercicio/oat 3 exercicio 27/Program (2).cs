﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oat_3_exercico_27
{
    internal class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
