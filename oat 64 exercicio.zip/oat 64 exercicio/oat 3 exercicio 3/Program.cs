﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oat_3_ex_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("NOME: ");
            string nome = Console.ReadLine();
            Console.Write("CODIGO DA PEÇA: ");
            int codigo = int.Parse(Console.ReadLine());
            Console.Write("PREÇO UNITARIO DA PEÇA: ");
            double preço = double.Parse(Console.ReadLine());
            Console.Write("QUANTIDADA VENDIDA: ");
            double quantidade = double.Parse(Console.ReadLine());

            double total_vendido = (preço * quantidade);
            double comiçao = (total_vendido * 5) / 100;

            Console.WriteLine("O VENDEDOR " + nome);
            Console.WriteLine("CODIGO DA PEÇA " + codigo);
            Console.WriteLine("PREÇO UNITARIO DA PEÇA " + preço);
            Console.WriteLine("QUANTIDADE VENDIDA " + quantidade);

            Console.WriteLine("=================================");
            Console.WriteLine("O TOTAL DAS VENDAS FOI DE " + total_vendido + " REAIS");
            Console.WriteLine("A COMIÇÃO DO VENDEDOR " + nome + " FOI DE " + comiçao + " REIAS");

            Console.ReadLine();
        }
    }
}
