﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oat_3_exercicio_25
{
    internal class Program
    {
        static void Main(string[] args)
        {


            Console.Write("ALTURA: ");
            double altura = double.Parse(Console.ReadLine());
            Console.Write("SEXO: ");
            string sexo = Console.ReadLine();
            Console.WriteLine("================================");

            //formula_masculina = (72.7 * altura) - 58;
            //formula_feminina = (62.1 * altura) - 44.7;


            if (sexo == "m")
            {
                double resultado = (72.7 * altura) - 58;
                Console.WriteLine("VOCE E DO SEXO MASCULINO SEU PESO IDEAL E " + resultado);
            }
            else
            {
                double resultado = (62.1 * altura) - 44.7;
                Console.WriteLine("VOCE E DO SEXO FEMININO SEU PESO IDEAL E " + resultado);
            }

            Console.ReadLine();

        }
    }
}
