﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oat_3_exercicio_43
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double total = 0;

            Console.Write("QUAL A QUANTIDADE DE SERVIÇOS ");
            int quant = int.Parse(Console.ReadLine());

            for (int cont = 1; cont <= quant; cont++)
            {
                if (total == 0)
                {
                    total = 1;
                }

                else
                {
                    total = total * 2;
                }

            }

            Console.WriteLine("VALOR TOTAL DO TRIGO: " + total);

            Console.ReadLine();
        }
    }
}
