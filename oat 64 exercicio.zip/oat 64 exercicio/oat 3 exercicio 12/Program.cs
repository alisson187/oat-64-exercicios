﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oat_3_exercicio_12
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("DIGITE UM NUMERO: ");
            int numero = int.Parse(Console.ReadLine());
            if (numero >= 0)
            {
                Console.WriteLine("ESSE NUMERO E MAIOR OU IGUAL A ZERO");
            }
            else
            {
                Console.WriteLine("ESSE NUMERO E MENOR QUE ZERO");
            }

            Console.ReadLine();

        }
    }
}
