﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oat_3_exercicio_37
{
    internal class Program
    {
        static void Main(string[] args)
        {

            string resposta = "";
            int resultado = 0;
            do
            {
                Console.WriteLine("[1] ADIÇAO\n[2] SUBTRAÇÃO\n[3] MULTIPLICAÇÃO\n[4] DIVISÃO");
                Console.Write("OPÇAO:");
                int opcao = int.Parse(Console.ReadLine());
                Console.Write("DIGITE UM VALOR ");
                int valor1 = int.Parse(Console.ReadLine());
                Console.Write("DIGITE OUTRO VALOR ");
                int valor2 = int.Parse(Console.ReadLine());
                if (opcao == 1)
                {
                    resultado = valor1 + valor2;
                }
                else if (opcao == 2)
                {
                    resultado = valor1 - valor2;
                }
                else if (opcao == 3)
                {
                    resultado = valor1 * valor2;
                }
                else
                {
                    resultado = valor1 / valor2;
                }
                Console.WriteLine("O RESULTADO DESSA OPERAÇÃO E " + resultado);
                Console.WriteLine("==========================================");
                Console.WriteLine("DIGITE 'S' OU 's' PARA CONTINUAR OU OUTRA TECLA PRA SAIR: ");
                resposta = Console.ReadLine();
            }
            while (resposta == "s");
            Console.WriteLine("=====FIM====");

            Console.ReadLine();
        }
    }
}
