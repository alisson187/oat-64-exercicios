﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oat_3_exercicio_15
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Console.Write("PRIMEIRA NOTA: ");
            double nota1 = double.Parse(Console.ReadLine());
            Console.Write("SEGUNDA NOTA: ");
            double nota2 = double.Parse(Console.ReadLine());
            Console.Write("TERCEIRA NOTA: ");
            double nota3 = double.Parse(Console.ReadLine());
            Console.Write("QUARTA NOTA: ");
            double nota4 = double.Parse(Console.ReadLine());
            Console.WriteLine("===============================");
            double media = (nota1 + nota2 + nota3 + nota4) / 4;

            if (media >= 7)
            {
                Console.WriteLine("PARABENS VOCE FOI APROVADO");
                Console.WriteLine("SUA MEDIA FOI DE " + media);
            }
            else if (media < 7)
            {
                Console.WriteLine("VOCE ESTA DE RECUPERAÇAO");
                Console.WriteLine("SUA MEDIA FOI DE " + media);
                Console.WriteLine("============================");
                Console.Write("DIGITE O VALOR DA SUA NOTA NA PROVA DE RECUPERAÇAO: ");
                double recuperaçao = double.Parse(Console.ReadLine());
                double media_final = media + recuperaçao;
                if (media_final >= 7)
                {
                    Console.WriteLine("=========================");
                    Console.WriteLine("PARABENS VOCE PASSOU NA SUA PROVA DE RECUPERAÇAO SUA MEDIA FOI DE " + media_final);
                }
                else
                {
                    Console.WriteLine("=============================");
                    Console.WriteLine("INFESLIMENTE VOCE REPROVOU SUA NOTA NA PROVA DE RECUPERAÇAO FOI DE " + media_final);
                }
            }

            Console.ReadLine();
        }
    }
}
