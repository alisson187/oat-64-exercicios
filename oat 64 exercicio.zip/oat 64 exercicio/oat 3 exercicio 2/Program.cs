﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace terceira_oat_ex_2
{
    internal class Program
    {
        static void Main(string[] args)
        {


            Console.WriteLine("CONVERTENDO DOLARES PARA REAL");
            Console.WriteLine("==============================");
            Console.Write("QUAL A CONTAÇAO DO DOLAR: ");
            double dolar = double.Parse(Console.ReadLine());
            Console.Write("INFORME O VALOR EM DOLARES: ");
            double valor = double.Parse(Console.ReadLine());
            double real = valor * dolar;
            Console.WriteLine("===============================");

            Console.Write("ESSE VALOR EM DOLARES CONVERTIDO PARA REAL E " + real);

            Console.ReadLine();
        }
    }
}
