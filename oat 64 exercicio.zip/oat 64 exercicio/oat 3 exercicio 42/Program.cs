﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oat_3_exercicio_42
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string opcao;
            int n1 = 0;
            int maior = int.MinValue;
            int menor = int.MaxValue;

            do
            {
                Console.WriteLine("DIGITE UM NUMERO ");
                n1 = int.Parse(Console.ReadLine());

                if (menor > n1)
                {
                    menor = n1;
                }
                if (maior < n1)
                {
                    maior = n1;
                }

                Console.WriteLine();

                Console.Write("DIGITE '0' OU OUTRO VALOR PARA CONTINUAR ");
                opcao = Console.ReadLine();
            }
            while (opcao != "0");

            Console.WriteLine("MAIOR NUMERO DIGITADO: " + maior);
            Console.WriteLine("MENOR NUMERO DIGITADO: " + menor);

            Console.ReadLine();
        }
    }
}
