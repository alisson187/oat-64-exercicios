﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oat_3_exercicio_17
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Console.Write("DIGITE UM NUMERO: ");
            int numero = int.Parse(Console.ReadLine());
            Console.WriteLine("========================");
            if (numero >= 0 && numero <= 9)
            {
                Console.WriteLine("VALOR VALIDO");
            }
            else
            {
                Console.WriteLine("VALOR INVALIDO");
            }

            Console.ReadLine();

        }
    }
}
