﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oat_3_exercicio_44
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string opcao = "";
            do
            {
                Console.WriteLine("===========ESCOLHA UM OPÇAO:============");
                Console.WriteLine("CELSIOS PARA CELSIOS===========COD => 1");
                Console.WriteLine("FAHREINHEIT PARA FAHRENHEIT==========COD => 2");
                Console.WriteLine("PESO IDEAL PARA HOMENS============COD => 3");
                Console.WriteLine("PESO IDEAL PARA MULHERS===========COD => 4");
                Console.Write("OPÇAO: ");
                int operacao = int.Parse(Console.ReadLine());


                double n1 = 0;
                double A = 0;
                double P = 0;
                double resultado = 0;
                double S = 0;

                switch (operacao)
                {
                    case 1:
                        Console.Write("DIGITE UM VALOR EM GRAUS CELSIOS ");
                        n1 = double.Parse(Console.ReadLine());

                        resultado = (9 * n1 + 160) / 5;

                        break;
                    case 2:
                        Console.WriteLine("DIGITE UM VALOR EM GRAUS FAHREITCH");
                        n1 = double.Parse(Console.ReadLine());
                        resultado = (n1 - 32) * 5 / 9;
                        break;
                    case 3:
                        Console.Write("ALTURA ");
                        A = double.Parse(Console.ReadLine());
                        Console.Write("PESO");
                        P = double.Parse(Console.ReadLine());
                        resultado = P / (A * A);

                        break;
                    case 4:
                        Console.Write("ALTURA ");
                        A = double.Parse(Console.ReadLine());
                        Console.Write("PESO");
                        P = double.Parse(Console.ReadLine());
                        resultado = P / (A * A);
                        break;
                }

                Console.WriteLine("RESULTADO : " + resultado);
                if (operacao == 3 || operacao == 4)
                {
                    if (resultado < 18.5)
                    {
                        Console.WriteLine("ABAIXO DO PESO");
                    }
                    else if (resultado >= 18.5 && resultado < 25)
                    {
                        Console.WriteLine("PESO NORMAL");
                    }
                    else if (resultado > 25)
                    {
                        Console.WriteLine("ACIMA DO PESO");
                    }
                }

                Console.WriteLine("");
                Console.WriteLine("DESEJA CONTINUAR DIGITE 's' OUTRA TECLA PARA SAIR");
                opcao = Console.ReadLine();

            }
            while (opcao == "s" || opcao == "S");

            Console.WriteLine("FIM");

            Console.ReadLine();
        }
    }
}
