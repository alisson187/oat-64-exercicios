﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oat_3_exercicio_11
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("DIGITE O VALOR DE 'A': ");
            int a = int.Parse(Console.ReadLine());
            Console.Write("DIGITE O VALOR DE 'B': ");
            int b = int.Parse(Console.ReadLine());

            int valor_a = a;
            a = b;
            b = valor_a;
            Console.WriteLine("=================================");
            Console.WriteLine("O VALOR DE 'A' PASSOU A SER " + a);
            Console.WriteLine("O VALOR DE 'B' PASSOU A SER " + b);

            Console.ReadLine();
        }
    }
}
