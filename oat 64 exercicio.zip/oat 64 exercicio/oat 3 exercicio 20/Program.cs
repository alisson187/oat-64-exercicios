﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oat_3_exercicio_20
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int menor, maior;
            Console.Write("VALOR 'A': ");
            int a = int.Parse(Console.ReadLine());
            Console.Write("VALOR 'B': ");
            int b = int.Parse(Console.ReadLine());
            Console.Write("VALOR 'C': ");
            int c = int.Parse(Console.ReadLine());
            maior = a;
            if (b > c)
            {
                maior = b;
            }
            else
            {
                maior = c;
            }
            menor = a;
            if (b < c)
            {
                menor = b;
            }
            else
            {
                menor = c;
            }
            Console.WriteLine("MENOR " + menor + " MULTIPLICADO POR " + maior + " E IGUAL A " + (menor * maior));
            Console.WriteLine("MAIOR " + maior + " DIVIDO POR " + menor + " E IGUAL A " + (maior / menor));

            Console.ReadLine();
        }
    }
}
