﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oat_3_exercicio_10
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("DIGITE O PRIMEIRO VALOR: ");
            int valor1 = int.Parse(Console.ReadLine());
            Console.Write("DIGITE O SEGUNDO VALOR: ");
            int valor2 = int.Parse(Console.ReadLine());

            if (valor1 == valor2)
            {
                Console.WriteLine("IGUAL");
            }
            else
            {
                Console.WriteLine("NAO IGUAL");
            }
            if (valor1 > valor2)
            {
                Console.WriteLine("MAIOR");
                Console.WriteLine("MAIOR OU IGUAL");
            }
            else
            {
                Console.WriteLine("MENOR");
                Console.WriteLine("MENOR OU IGUAL");
            }


            Console.ReadLine();
        }
    }
}
