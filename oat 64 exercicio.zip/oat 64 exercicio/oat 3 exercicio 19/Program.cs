﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oat_3_exercicio_19
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("VALOR DO LADO A: ");
            int a = int.Parse(Console.ReadLine());
            Console.Write("VALOR DO LADO B: ");
            int b = int.Parse(Console.ReadLine());
            Console.Write("VALOR DO LADO C: ");
            int c = int.Parse(Console.ReadLine());
            if (a < b + c && b < a + c && c < a + b)
            {
                if (a == b && b == c)
                {
                    Console.WriteLine("TRIÂNGULO EQUILATERO");
                }
                else if (a == b || a == c || b == c)
                {
                    Console.WriteLine("TRIÂNGULO ISOSCELES");
                }
                else
                {
                    Console.WriteLine("TRIÂNGULO ESCALENO");
                }

            }
            else
            {
                Console.WriteLine("OS VALORES NAO FORMAM UM TRIANGULO");
            }

            Console.ReadLine();
        }
    }
}
