﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oat_3_exercicio_60
{
    internal class Program
    {
        static void Main(string[] args)
        {
            static int VerificaQuadrante(int x, int y)
            {
                static int VerificaQuadrante(int x, int y)
                {
                    if (x > 0 && y > 0)
                    {
                        return 1;
                    }
                    else if (x < 0 && y > 0)
                    {
                        return 2;
                    }
                    else if (x < 0 && y < 0)
                    {
                        return 3;
                    }
                    else if (x > 0 && y < 0)
                    {
                        return 4;
                    }
                    else
                    {
                        return 0; // Origem (0, 0) ou algum ponto na linha dos eixos
                    }
                }

                static void Main(string[] args)
                {
                    Console.WriteLine("Digite as coordenadas do ponto (x, y):");
                    int x = int.Parse(Console.ReadLine());
                    int y = int.Parse(Console.ReadLine());

                    int quadrante = VerificaQuadrante(x, y);

                    if (quadrante == 0)
                    {
                        Console.WriteLine("O ponto está na origem (0, 0) ou em algum ponto da linha dos eixos.");
                    }
                    else
                    {
                        Console.WriteLine("O ponto está no quadrante {0}.", quadrante);
                    }
                }
            }
        }
    }
}
        