﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oat_3_exercicio_63
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("DIGITE UM NUMERO INTEIRO: ");
            int numero = int.Parse(Console.ReadLine());

            string resultado = Verifica(numero);

            Console.WriteLine(resultado);

            Console.ReadLine();
        }

        static string Verifica(int numero)
        {
            if (numero % 2 == 0)
            {
                return "PAR";
            }
            else
            {
                return "ÍMPAR";
            }
            Console.ReadLine();

        }
    }
    
}
