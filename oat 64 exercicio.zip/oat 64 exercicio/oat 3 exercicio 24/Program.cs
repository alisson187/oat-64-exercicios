﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oat_3_exercicio_24
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int opçao = 0;
            int cont = 0;
            while (opçao != 4)
            {
                Console.Write("DIGITE O PRIMEIRO VALOR: ");
                int valor1 = int.Parse(Console.ReadLine());
                Console.Write("DIGITE O SEGUNDO VALOR: ");
                int valor2 = int.Parse(Console.ReadLine());
                Console.WriteLine("================OPÇAO====================");
                Console.WriteLine("(1)VERIFICAR SE UM DOS NUMEROS E MULTIPLO DO OUTRO");
                Console.WriteLine("(2)VERIFICAR SE OS DOIS NUMEROS SAO PARES");
                Console.WriteLine("(3)A MEDIA E MAIOR OU IGUAL A 7");
                Console.WriteLine("(4) SAIR");
                Console.WriteLine("==========================================");
                Console.Write("OPÇAO: ");
                opçao = int.Parse(Console.ReadLine());
                if (opçao == 1)
                {
                    if (valor1 % valor2 == 1)
                    {
                        Console.WriteLine("O PRIMEIRO VALO NAO E MULTIPLO DO SEGUNDO VALOR");
                    }
                    else
                    {
                        Console.WriteLine(" O PRIMEIRO VALOR E MULTIPLO DO SEGUNDO VALOR");
                    }
                    if (valor2 % valor1 == 1)
                    {
                        Console.WriteLine("O SEGUNDO VALOR NÃO E MULTIPLO DO PRIMEIRO VALOR");
                    }
                    else
                    {
                        Console.WriteLine(" O SEGUNDO VALOR E MULTIPLO DO PRIMEIRO VALOR");
                    }
                }
                if (opçao == 2)
                {
                    if (valor1 % 2 == 0 && valor2 % 2 == 0)
                    {
                        Console.WriteLine("OS DOIS VALORES SÃO PARES");
                    }
                    else
                    {
                        Console.WriteLine("UM DOS VALORES NÃO E PAR");
                    }
                }
                if (opçao == 3)
                {
                    double media = (valor1 + valor2) / 2;
                    if (media >= 7)
                    {
                        Console.WriteLine("MEDIA MAIOR QUE 7 A MEDIA FOI " + media);
                    }
                    else
                    {
                        Console.WriteLine("MEDIA MENOR QUE 7 A MEDIA FOI " +
                        media);
                    }
                }
                cont++;
            }
            Console.WriteLine("=====FIM====");

            Console.ReadLine();
        }
    }
}
