﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oat_3_exercicio_49
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n = 0;
            do
            {
                Console.Write("INFORME O TAMANHO DOS VETORES ( 1 e 50): ");
                n = int.Parse(Console.ReadLine());
            } while (n < 1 || n > 50);

            
            int[] v1 = new int[n];
            int[] v2 = new int[n];

        
            Console.WriteLine("DIGITE OS ELEMENTOS DO VETOR V1:");
            for (int i = 0; i < n; i++)
            {
                Console.Write("ELEMENTO {0}: ", i + 1);
                v1[i] = int.Parse(Console.ReadLine());
            }

            Console.WriteLine("DIGITE OS ELEMENTOS DO VETOR V2:");
            for (int i = 0; i < n; i++)
            {
                Console.Write("ELEMENTO {0}: ", i + 1);
                v2[i] = int.Parse(Console.ReadLine());
            }

          
            int contador = 0;

 
            for (int i = 0; i < n; i++)
            {
                if (v1[i] == v2[i])
                {
                    contador++;
                }
            }


            Console.WriteLine("QUANTIDADES DE VALORES INDENTICOS NAS MESMAS POSIÇOES: " + contador);

            Console.ReadLine();
        }
    }

}
    

