﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oat_3_exercico_33
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int cont = 1;
            while (cont >= 1)
            {
                Console.Write("INFORME O NUMERO DE MATRICULA DO " + cont + " ALUNO: ");
                int matricula = int.Parse(Console.ReadLine());
                Console.Write("PRIMEIRA NOTA: ");
                double a = double.Parse(Console.ReadLine());
                Console.Write("SEGUNDA NOTA: ");
                double b = double.Parse(Console.ReadLine());
                double media = a + b / 2;
                Console.WriteLine("O ALUNO DA MATRICULA " + matricula + " FICOU COM A MEDIA => " + media);
                Console.Write("DIGITE 's' PARA SAIR | E 'c' PARA CONTINUAR: ");
                string resposta = Console.ReadLine();
                Console.WriteLine("====================================");
                cont++;
                if (resposta == "s")
                {
                    Console.WriteLine("FIM");
                    break;

                }
                Console.ReadLine();
            }
        }
    }
}
