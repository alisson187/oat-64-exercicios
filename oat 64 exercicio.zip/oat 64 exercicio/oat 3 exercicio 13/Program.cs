﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oat_3_exercicio_13
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("DIGITE O PRIMEIRO VALOR: ");
            int valor1 = int.Parse(Console.ReadLine());
            Console.Write("DIGITE O SEGUNDO VALOR: ");
            int valor2 = int.Parse(Console.ReadLine());
            Console.Write("DIGITE O TERCEIRO VALOR: ");
            int valor3 = int.Parse(Console.ReadLine());
            Console.WriteLine("========================");

            if (valor1 > valor2 && valor1 > valor3)
            {
                if (valor2 > valor3)
                {
                    Console.WriteLine(valor1);
                    Console.WriteLine(valor2);
                    Console.WriteLine(valor3);
                }
                else
                {
                    Console.WriteLine(valor1);
                    Console.WriteLine(valor3);
                    Console.WriteLine(valor2);
                }
            }
            if (valor2 > valor1 && valor2 > valor3)
            {
                if (valor1 > valor3)
                {
                    Console.WriteLine(valor2);
                    Console.WriteLine(valor1);
                    Console.WriteLine(valor3);
                }
                else
                {
                    Console.WriteLine(valor2);
                    Console.WriteLine(valor3);
                    Console.WriteLine(valor1);
                }
                if (valor3 > valor1 && valor3 > valor2)
                {
                    if (valor1 > valor2)
                    {
                        Console.WriteLine(valor3);
                        Console.WriteLine(valor1);
                        Console.WriteLine(valor2);
                    }
                    else
                    {
                        Console.WriteLine(valor3);
                        Console.WriteLine(valor2);
                        Console.WriteLine(valor1);
                    }
                }
            }

            Console.ReadLine();

        }
    }
}
