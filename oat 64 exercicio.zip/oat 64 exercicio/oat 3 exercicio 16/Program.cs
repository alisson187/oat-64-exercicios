﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oat_3_exercicio_16
{
    internal class Program
    {
        static void Main(string[] args)
        {


            Console.Write("DIGITE O PRIMEIRO VALOR: ");
            int valor1 = int.Parse(Console.ReadLine());
            Console.Write("DIGITE O SEGUNDO VALOR: ");
            int valor2 = int.Parse(Console.ReadLine());
            Console.WriteLine("===================================");

            if (valor1 > valor2)
            {
                Console.WriteLine("O VALOR " + valor1 + " E MAIOR QUE " + valor2);
            }
            else if (valor2 > valor1)
            {
                Console.WriteLine("O VALOR " + valor2 + " E MAIOR QUE " + valor1);
            }
            else
            {
                Console.WriteLine("OS VALORES " + valor1 + " E " + valor2 + " SÃO VALORES IGUAIS");
            }

            Console.ReadLine();

        }
    }
}
