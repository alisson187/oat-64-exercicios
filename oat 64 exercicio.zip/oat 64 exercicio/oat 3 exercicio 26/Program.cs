﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oat_3_exercicio_26
{
    internal class Program
    {
        static void Main(string[] args)
        {
            for (int cont = 100; cont >= 1; cont--)
            {
                Console.WriteLine(cont);
            }

            Console.ReadLine();

        }
    }
}
