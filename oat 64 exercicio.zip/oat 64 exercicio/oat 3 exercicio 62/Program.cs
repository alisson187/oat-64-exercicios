﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oat_3_exercicio_62
{
    internal class Program
    {
        static void Main(string[] args)
        {
            static double Hipotenusa(double baseTriangulo, double alturaTriangulo)
            {
                double hipotenusa = Math.Sqrt(Math.Pow(baseTriangulo, 2) + Math.Pow(alturaTriangulo, 2));
                return hipotenusa;
            }

            static void Main(string[] args)
            {
                Console.WriteLine("INFORME O VALOR DA BASE DO TRIANGULO: ");
                double baseTriangulo = double.Parse(Console.ReadLine());

                Console.WriteLine("INFORME O VALOR DA ALTURA DO TRIAGULO: ");
                double alturaTriangulo = double.Parse(Console.ReadLine());

                double hipotenusa = Hipotenusa(baseTriangulo , alturaTriangulo);

                Console.WriteLine("O VALOR DA HIPOTENUZA E: " + hipotenusa);
            }
        }
    }
}
