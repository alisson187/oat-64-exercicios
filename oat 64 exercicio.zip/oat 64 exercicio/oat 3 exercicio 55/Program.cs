﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oat_3_exercicio_55
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("ESCREVA UMA FRASE DE ATE 50 CARACTERES: ");
            string frase = Console.ReadLine();


            string fraseSemEspacos = frase.Replace(" ", "");


            int quantidadeEspacos = frase.Length - fraseSemEspacos.Length;

            Console.WriteLine("FRASES SEM ESPAÇOS EM BRANCO: " + fraseSemEspacos);
            Console.WriteLine("QUANTIDADE DE ESPAÇOS EM BRANCO: " + quantidadeEspacos);

            Console.ReadLine();
        }
    }
}
