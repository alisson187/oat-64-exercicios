﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oat_3_exercicio_59
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("DIGITE DUAS LETRAS DE A a Z EM ORDEM ALFABETICA: ");
            char char1 = char.Parse(Console.ReadLine());
            char char2 = char.Parse(Console.ReadLine());

            if (char1 >= 'A' && char1 <= 'Z' && char2 >= 'A' && char2 <= 'Z')
            {
                if (char1 > char2)
                {
                    Console.WriteLine("ESTA ERRADO AS LETRAS NAO ESTAO EM ORDEM ALFABETICA.");
                }
                else
                {
                    int numCaracteres = char2 - char1 - 1;
                    Console.WriteLine("O NUMERO DE CARACTERES ENTRE '{0}' e '{1}' é: {2}", char1, char2, numCaracteres);
                }
            }
            else
            {
                Console.WriteLine("ESTA ERRADO AS LETRAS DEVEM SER MAIUSCULAS DE A a Z.");
            }

            Console.ReadLine();
        }
    }
}
