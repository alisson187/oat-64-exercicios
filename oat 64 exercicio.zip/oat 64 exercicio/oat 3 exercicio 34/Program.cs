﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oat_3_exercicio_34
{
    internal class Program
    {
        static void Main(string[] args)
        {

            int valor = 0;
            int menor = 0;
            int maior = 0;
            do
            {
                Console.Write("DIGITE UM VALOR OU UM NUMERO NEGATIVO PARA SAIR: ");
                valor = int.Parse(Console.ReadLine());

                if (valor > maior)
                {
                    maior = valor;
                }
                if (valor < menor)
                {
                    menor = valor;
                }

            }
            while (valor >= 0);
            Console.WriteLine("==========FIM==========");
            Console.WriteLine("O MAIOR VALOR E " + maior);
            Console.WriteLine("O MENOR VALOR E " + menor);

            Console.ReadLine();

        }
    }
}
