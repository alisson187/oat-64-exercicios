﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oat_3_exercicio_40
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string opcao = "";


            do
            {

                Console.Write("QUAL NIVEL DE POLUIÇÃO: ");
                double n1 = double.Parse(Console.ReadLine());

                if (n1 <= 0.25)
                {
                    Console.WriteLine("DENTRO DOS PARAMETROS NAO PRECISA ENCERRAR AS ATIVIDADES");
                }
                else if (n1 > 0.25 && n1 < 0.30)
                {
                    Console.WriteLine("FORA DO PARAMETRO,NAO HA NECESSIDADE DE SUSPENÇAO DE ATIVIDADE");
                }
                else if (n1 >= 0.30 && n1 < 0.40)
                {
                    Console.WriteLine("INDUSTRIA NIVEL 1 SUSPENDAM SUAS ATIVIDADES");
                }
                else if (n1 >= 0.40 && n1 < 0.50)
                {
                    Console.WriteLine("INDUSTRIAS NIVEL 1 E 2 SUPENDAM SUAS ATIVIDADES");

                }
                else if (n1 >= 0.50)
                {
                    Console.WriteLine("INDUSTRIAS NIVEL 1, 2 ,3 SUSPENDAM SUAS ATIVIDADES");

                }


                Console.WriteLine("PARA SAIR TECLE 's' E OUTRA TECLA PARA CONTINUAR");
                opcao = Console.ReadLine();
            }
            while (opcao != "s" && opcao != "S");

            Console.WriteLine("FIM");

            Console.ReadLine();
        }
    }
}
