﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oat_3_exercicio_56
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] vetor = new int[50];
            int quantidadePares = 0;
            int quantidadeMultiplosDe5 = 0;

            Console.WriteLine("INFORME OS VALORES DO VETOR:");

            for (int i = 0; i < 50; i++)
            {
                Console.Write("VETOR[{0}]: ", i);
                vetor[i] = int.Parse(Console.ReadLine());

                if (vetor[i] % 2 == 0)
                {
                    quantidadePares++;
                }

                if (vetor[i] % 5 == 0)
                {
                    quantidadeMultiplosDe5++;
                }
            }

            Console.WriteLine("QUANTIDADE DE PARES: " + quantidadePares);
            Console.WriteLine("QUANTIDADE DE MULTIPLOS DE 5: " + quantidadeMultiplosDe5);

            Console.ReadLine();
        }
    }
}
