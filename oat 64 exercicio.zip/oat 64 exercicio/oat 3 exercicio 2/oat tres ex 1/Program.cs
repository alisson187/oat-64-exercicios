﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oat_tres_ex_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("CALCULANDO O ESQUE MEDIO DE UMA PEÇA");
            Console.WriteLine("=====================================");
            Console.Write("QUAL A QUANTIDADE MINIMA DESSA PEÇA ");
            int quantidade_minima = int.Parse(Console.ReadLine());
            Console.Write("QUAL A QUANTIDADE MAXIMA DESSA PEÇA ");
            int quantidade_maxima = int.Parse(Console.ReadLine());

            double estoque_medio = (quantidade_minima + quantidade_maxima) / 2;
            Console.WriteLine("==========================================");

            Console.WriteLine("O ESTOQUE MEDIO DESSA PEÇA E " + estoque_medio);


            Console.ReadLine();

        }
    }
}
