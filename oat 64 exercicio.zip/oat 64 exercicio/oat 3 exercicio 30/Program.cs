﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oat_3_exercicio_30
{
    internal class Program
    {
        static void Main(string[] args)
        {

            int cont = 1;
            Console.Write("DIGITE UM NUMERO PARA A TABUADA: ");
            int numero = int.Parse(Console.ReadLine());
            while (cont <= 10)
            {
                Console.WriteLine(numero + "x" + cont + "=" + numero * cont);
                cont++;
            }
            Console.ReadLine();

        }
    }
}
