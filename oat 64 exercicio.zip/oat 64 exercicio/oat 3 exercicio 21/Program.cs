﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oat_3_exercicio_21
{
    internal class Program
    {
        static void Main(string[] args)
        {


            string resposta = "";

            do
            {
                Console.WriteLine("DIGITE UM NUMERO: ");
                int numero = int.Parse(Console.ReadLine());
                Console.WriteLine("=======================");
                if (numero > 0)
                {
                    Console.WriteLine("NUMERO POSITIVO");
                }
                else if (numero == 0)
                {
                    Console.WriteLine("NUMERO NULO");
                }
                else
                {
                    Console.WriteLine("NUMERO NEGATIVO");
                }
                Console.WriteLine("DIGITE 'S' OU 's' PARA SAIR E OUTRA TECLA PARA CONTINUAR: ");
                resposta = Console.ReadLine();
            }
            while (resposta != "S" && resposta != "s");
            Console.WriteLine("=======FIM======");

            Console.ReadLine();
        }
    }
}
