﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oat_3_exercicio_61
{
    internal class Program
    {
        static void Main(string[] args)
        {
            static decimal Reajuste(decimal salario, decimal indice)
            {
                decimal salarioAtualizado = salario + (salario * indice);
                return salarioAtualizado;
            }

            static void Main(string[] args)
            {
                Console.WriteLine("INFORME O VALOR DO SALARIO: ");
                decimal salario = decimal.Parse(Console.ReadLine());

                Console.WriteLine("INFORME O INDICE DE REAJUSTE (EM DECIMAL): ");
                decimal indice = decimal.Parse(Console.ReadLine());

                decimal salarioAtualizado = Reajuste(salario, indice);

                Console.WriteLine("O SALARIO ATUALIZADO E : " + salarioAtualizado.ToString("C2"));
            }
        }
    }
}
