﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oat_3_exercicio_48
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int quantidadeCandidatas = 20;


            string[] nomes = new string[quantidadeCandidatas];
            int[] idades = new int[quantidadeCandidatas];


            Console.WriteLine("DIGITE O NOME E IDADE DAS CANDIDATAS :");
            for (int i = 0; i < quantidadeCandidatas; i++)
            {
                Console.Write("NOME DA CANDIDATA {0}: ", i + 1);
                nomes[i] = Console.ReadLine();

                Console.Write("IDADE DA CANDIDATA {0}: ", i + 1);
                idades[i] = int.Parse(Console.ReadLine());
            }

      
            string[] candidatasAptas = new string[quantidadeCandidatas];
            int contador = 0;

     
            for (int i = 0; i < quantidadeCandidatas; i++)
            {
                if (idades[i] >= 18 && idades[i] <= 20)
                {
                    candidatasAptas[contador] = nomes[i];
                    contador++;
                }
            }


            Console.WriteLine("CANDIDATAS APTAS PARA A CAMPANHA PUBLICITARIA :");
            for (int i = 0; i < contador; i++)
            {
                Console.WriteLine(candidatasAptas[i]);
            }

            Console.ReadLine();
        }
    }

}
    

