﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oat_3_exercicio_38
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string opcao = "";
            double e = 0;

            do
            {

                Console.Write("DIGITE O CODIGO: ");
                double c = double.Parse(Console.ReadLine());
                Console.Write("HORAS TRABALHADAS: ");
                double n = double.Parse(Console.ReadLine());


                if (n > 50)
                {
                    e = (n - 50) * 20;
                    Console.Write("SALARIO TOTAL: R$ " + (500 + e));
                    Console.WriteLine("SALARIO EXCEDENTE: R$ " + e);
                }
                else
                {
                    Console.WriteLine("SALARIO TOTAL: R$ " + (n * 10));
                    Console.WriteLine("SALARIO EXCEDENTE: R$ " + e);
                }


                Console.Write("DESEJA ENCERRAR DIGITE 'S': ");
                opcao = Console.ReadLine();
            }
            while (opcao != "s" && opcao != "S");

            Console.WriteLine("FIM");

            Console.ReadLine();
        }
    }
}
