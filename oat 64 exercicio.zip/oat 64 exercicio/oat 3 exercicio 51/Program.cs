﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oat_3_exercicio_51
{
    internal class Program
    {
        static void Main(string[] args)
        {
            const int tamanhoMaximo = 100;
            int[] vetor = new int[tamanhoMaximo];
            int contadorUm = 0;
            int contadorTres = 0;
            int contadorQuatro = 0;
            int contador = 0;

            Console.WriteLine("DIGITE OS NUMEROS INTEIROS POSITIVOS SEPARADOS POR ESPAÇO (OU -1 PARA SAIR): ");

            while (contador < tamanhoMaximo)
            {
                int numero = int.Parse(Console.ReadLine());

                if (numero == -1)
                {
                    break;
                }

                vetor[contador] = numero;
                contador++;

                if (numero == 1)
                {
                    contadorUm++;
                }
                else if (numero == 3)
                {
                    contadorTres++;
                }
                else if (numero == 4)
                {
                    contadorQuatro++;
                }
            }

            Console.WriteLine("TOTAL DE VEZES QUE APARECE O NUMERO  1: " + contadorUm);
            Console.WriteLine("TOTAL DE VEZES QUE APARECE O NUMERO  3: " + contadorTres);
            Console.WriteLine("TOTAL DE VEZES QUE APARECE O NUMERO 4: " + contadorQuatro);

            Console.ReadLine();

        }
    }
}
