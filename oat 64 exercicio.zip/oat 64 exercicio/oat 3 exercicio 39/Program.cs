﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oat_3_exercicio_39
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string opcao = "";
            double E = 0;

            do
            {

                Console.Write("DIGITE UM NUMERO:");
                double n1 = double.Parse(Console.ReadLine());

                if (n1 % 2 == 0)
                {
                    Console.WriteLine(n1 + " E PAR");
                }
                else
                {
                    Console.WriteLine(n1 + " E IMPAR");
                }
                if (n1 > 0)
                {
                    Console.WriteLine(n1 + " E POSITIVO");
                }
                else if (n1 == 0)
                {
                    Console.WriteLine(n1 + " E NULO");
                }
                else
                {
                    Console.WriteLine(n1 + " E NEGATIVO");
                }


                Console.Write("DIGITE 'S' PARA SAIR E OUTRA TECLA PARA CONTINUAR ");
                opcao = Console.ReadLine();
            }
            while (opcao != "s" && opcao != "S");

            Console.WriteLine("FIM");

            Console.ReadLine();
        }
    }
}
