﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oat_3_exercicio_6
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
