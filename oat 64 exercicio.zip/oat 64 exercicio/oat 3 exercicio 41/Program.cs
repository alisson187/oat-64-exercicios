﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oat_3_exercicio_41
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("IDADE: ");
            int idade = int.Parse(Console.ReadLine());

            if (idade > 5 && idade <= 7)
            {
                Console.WriteLine("CATEGORIA INFANTIL A");
            }
            else if (idade > 7 && idade <= 11)
            {
                Console.WriteLine("CATEGORIA INFANTIL B");

            }
            else if (idade > 11 && idade <= 13)
            {
                Console.WriteLine("CATEGORIA JUVENIL A");

            }
            else if (idade > 13 && idade <= 17)
            {
                Console.WriteLine("CATEGORIA JUVENIL B");

            }
            else if (idade > 18)
            {
                Console.WriteLine("ADULTO");
            }
            else
            {
                Console.WriteLine("ESSA IDADE NAO E ACEITA");
            }

            Console.ReadLine();
        }
    }
}
