﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oat_3_exercicio_5
{
    internal class Program
    {
        static void Main(string[] args)
        {

            double km = 12;
            Console.Write("QUAL FOI O TEMPO DA VIAGEM: ");
            double tempo = double.Parse(Console.ReadLine());
            Console.Write("QUAL FOI A VELOCIDADE MEDIA: ");
            double velocidade = double.Parse(Console.ReadLine());

            double distancia = (tempo * velocidade);
            double litros_usados = distancia / km;
            Console.WriteLine("========================================");
            Console.WriteLine("A VELOCIDADE MEDIA FOI DE " + velocidade + " km/h");
            Console.WriteLine("O TEMPO GASTO NA VIAGEM FOI DE " + tempo + " HORAS");
            Console.WriteLine("A DISTANCIA PERCORRIDA FOI DE " + distancia + " km");
            Console.WriteLine("FORAM USADOS " + litros_usados + " LITROS DE COMBUSTIVEL");

            Console.ReadLine();
        }
    }
}
