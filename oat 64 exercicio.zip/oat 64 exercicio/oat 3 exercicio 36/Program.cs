﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oat_3_exercicio_36
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int menor = 0;
            int maior = 0;
            int cont = 1;
            int soma = 0;
            while (cont <= 10)
            {
                Console.Write("DIGITE UM VALOR: ");
                int valor = int.Parse(Console.ReadLine());
                cont++;
                soma += valor;
                if (valor > maior)
                {
                    maior = valor;
                }
                if (valor < menor)
                {
                    menor = valor;
                }
            }
            double media = soma / cont;
            Console.WriteLine("O MAIOR VALOR E " + maior);
            Console.WriteLine("O MENOR VALOR E " + menor);
            Console.WriteLine("A MEDIA DESSES VALORES E " + media);

            Console.ReadLine();
        }
    }
}
