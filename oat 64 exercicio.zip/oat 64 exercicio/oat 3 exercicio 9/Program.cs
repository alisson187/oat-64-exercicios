﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oat_3_ex_9
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Console.Write("IDADE: ");
            int idade = int.Parse(Console.ReadLine());
            Console.Write("MESES: ");
            int meses = int.Parse(Console.ReadLine());
            Console.Write("DIAS: ");
            int dias = int.Parse(Console.ReadLine());

            int idade_em_dias = (idade * 365) + (meses * 30) + dias;

            Console.WriteLine("SUA IDADE EM DIAS E " + idade_em_dias + " DIAS");

            Console.ReadLine();
        }
    }
}
