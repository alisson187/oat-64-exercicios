﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oat_3_exercicio_50
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Random random = new Random();
            int numeroSorteado = random.Next(101);
            int tentativas = 0;
            int tentativa;

            Console.WriteLine("BEM VINDO AO JOGO DA ADIVINHAÇAO!");
            Console.WriteLine("TENTE ADIVINHAR UM NUMERO ENTRE '0 E 100'.");

            do
            {
                Console.Write("QUAL SERA SUA TENTATIVA: ");
                tentativa = int.Parse(Console.ReadLine());
                tentativas++;

                if (tentativa < numeroSorteado)
                {
                    Console.WriteLine("O NUMERO SORTEADO E MAIOR QUE SUA TENTATIVA. ");
                }
                else if (tentativa > numeroSorteado)
                {
                    Console.WriteLine("O NUMERO SORTEADO E MENOR QUE A SUA TENTATIVA. ");
                }
                else
                {
                    Console.WriteLine("PARABENS VOCE ACERTOU O NUMERO SORTEADO EM  " + tentativas + " TENTATIVAS.");
                }
            }
            while (tentativa != numeroSorteado);

            Console.ReadLine();
        }
    }

}
    

