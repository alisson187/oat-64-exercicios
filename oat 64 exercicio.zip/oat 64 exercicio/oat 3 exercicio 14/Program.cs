﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oat_3_exercicio_14
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Console.Write("DIGITE O PRIMEIRO VALOR: ");
            int valor1 = int.Parse(Console.ReadLine());
            Console.Write("DIGITE O SEGUNDO VALOR: ");
            int valor2 = int.Parse(Console.ReadLine());

            if (valor1 > valor2)
            {
                int valor1_maior = valor1 - valor2;
                int diferença = valor1_maior;
                Console.WriteLine("A DIFERENÇA DE " + valor1 + " PARA " + valor2 + " E DE " + diferença + " NUMEROS");
            }
            else
            {
                int valor2_maior = valor2 - valor1;
                int diferença = valor2_maior;
                Console.WriteLine("A DIFERENÇA DE " + valor2 + " PARA " + valor1 + " E DE " + diferença + " NUMEROS");

            }

            Console.ReadLine();
        }
    }
}
