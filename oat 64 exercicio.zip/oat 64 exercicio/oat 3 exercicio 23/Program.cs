﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oat_3_exercicio_23
{
    internal class Program
    {
        static void Main(string[] args)
        {


            Console.Write("DIGITE O PRIMEIRO VALOR: ");
            int valor1 = int.Parse(Console.ReadLine());
            Console.Write("DIGITE O SEGUNDO VALOR: ");
            int valor2 = int.Parse(Console.ReadLine());
            Console.WriteLine("ESCOLHA UMA OPÇAO\n=================");
            Console.WriteLine("[1]ADIÇÃO\n[2]SUBTRAÇÃO\n[3]MULTIPLICAÇÃO\n[4]DIVISÃO\n============");
            Console.Write("OPÇÃO: ");
            int opçao = int.Parse(Console.ReadLine());
            if (opçao == 1)
            {
                int soma = valor1 + valor2;
                Console.WriteLine("A SOMA DESSES VALORE E " + soma);
            }
            else if (opçao == 2)
            {
                int subtraçao = valor1 - valor2;
                Console.WriteLine("A SUBTRAÇÃO DESSES VALORES E " + subtraçao);
            }

            else if (opçao == 3)
            {
                int multiplicaçao = valor1 * valor2;
                Console.WriteLine("A MULTIPLICAÇAO DESSES VALORES E " + multiplicaçao);
            }

            else if (opçao == 4)
            {
                int divisao = valor1 / valor2;
                Console.WriteLine("A DIVISÂO DESSES VALORES E " + divisao);
            }
            else
            {
                Console.WriteLine("OPÇAO INVALIDA TENTE NOVAMENTE");
            }

            Console.ReadLine();

        }
    }
}
