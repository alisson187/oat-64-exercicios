﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oat_3_exercicio_57
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Digite uma frase:");
            string frase = Console.ReadLine();

            Console.WriteLine("Vogais na frase:");

            for (int i = 0; i < frase.Length; i++)
            {
                char caractere = frase[i];

                if (IsVowel(caractere))
                {
                    Console.Write(caractere);
                }
            }

            Console.WriteLine();
        }

        static bool IsVowel(char c)
        {
            c = char.ToLower(c);

            if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u')
            {
                return true;
            }

                return false;

          
        }
       
    }
}
