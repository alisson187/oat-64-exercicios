﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oat_3_ex_8
{
    internal class Program
    {
        static void Main(string[] args)
        {


            Console.WriteLine("CALCULANDO O VOLUME DE UMA LATA DE OLEO");
            Console.WriteLine("========================================");
            Console.Write("QUAL O VALOR RAIO: ");
            double r = double.Parse(Console.ReadLine());
            Console.Write("QUAL O VALOR DA ALTURA: ");
            double a = double.Parse(Console.ReadLine());

            double v = 3.14159 * r * r * a;

            Console.WriteLine("=========================================");
            Console.WriteLine("O VALOR DO VOLUME DA LATA DE OLEO E " + v);

            Console.ReadLine();
        }
    }
}
