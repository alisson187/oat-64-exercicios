﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oat_3_exercicio_22
{
    internal class Program
    {
        static void Main(string[] args)
        {


            int a = 0;
            int b = 0;
            Console.Write("DIGITE UM NUMERO: ");
            int numero = int.Parse(Console.ReadLine());
            Console.WriteLine("==========================================");
            if (numero >= 0)
            {
                a = numero;
                Console.WriteLine("O NUMERO " + a + " E POSITIVO E ESTA ARMAZENDO NA VARIAVEL 'A'");
            }
            else
            {
                b = numero;
                Console.WriteLine("O NUMERO " + b + " E NEGATIVO E ESTA ARMAZENADO NA VARIAVEL 'B'");
            }

            Console.ReadLine();

        }
    }
}
