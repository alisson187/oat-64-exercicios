﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oat_3_exercicio_52
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Idade da candidata {0}: ", i + 1);
            idades[i] = int.Parse(Console.ReadLine());


         
            string[] candidatasAptas = new string[quantidadeCandidatas];
            int contador = 0;

 
            for (int i = 0; i < quantidadeCandidatas; i++)
            {
                if (idades[i] >= 18 && idades[i] <= 20)
                {
                    candidatasAptas[contador] = nomes[i];
                    contador++;
                }
            }

 
            Console.WriteLine("Candidatas aptas para a campanha publicitária:");
            for (int i = 0; i < contador; i++)
            {
                Console.WriteLine(candidatasAptas[i]);
            }
        }
    }
        