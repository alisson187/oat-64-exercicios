﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oat_3_exercicio_54
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] vetorA = { 1, 2, 3, 4, 5 };
            int[] vetorB = { 4, 5, 6, 7, 8, 9, 10, 11 };

            Console.WriteLine("ELEMENTO COMUM AOS VETORES A e B:");

            for (int cont = 0; cont < vetorA.Length; cont++)
            {
                for (int j = 0; j < vetorB.Length; j++)
                {
                    if (vetorA[cont] == vetorB[j])
                    {
                        Console.WriteLine(vetorA[cont]);
                        break;
                    }
                }

            }

            Console.ReadLine();
        }
    }
}
