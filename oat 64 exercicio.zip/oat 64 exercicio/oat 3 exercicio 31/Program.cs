﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oat_3_exercicio_31
{
    internal class Program
    {
        static void Main(string[] args)
        {

            int somaimpar = 0;
            int somapar = 0;
            int cont = 1;
            while (cont >= 1)
            {
                Console.WriteLine("( DIGITE -1 PARA 'SAIR':) ");
                Console.Write("DIGITE O " + cont + " VALOR: ");
                int valor = int.Parse(Console.ReadLine());
                if (valor % 2 == 0)
                {
                    somapar = somapar + valor;
                    Console.WriteLine(valor + " PAR");
                }
                else
                {
                    somaimpar = somaimpar + valor;
                    Console.WriteLine(valor + " IMPAR");
                }
                if (valor < 0)
                {
                    Console.WriteLine("==============");
                    Console.WriteLine("      FIM      ");
                    break;
                }
                cont++;

            }
            Console.WriteLine("A SOMA DOS PARES FOI " + somapar);
            Console.WriteLine("A SOMA DOS IMPARES FOI " + somaimpar);

            Console.ReadLine();
        }
    }
}
