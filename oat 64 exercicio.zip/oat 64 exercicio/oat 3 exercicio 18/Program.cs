﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oat_3_exercicio_18
{
    internal class Program
    {
        static void Main(string[] args)
        {

            string numero = "";
            Console.Write("DIGITE UM NUMERO QUE SEJA (1) (2) OU (3): ");
            int codigo = int.Parse(Console.ReadLine());

            switch (codigo)
            {
                case 1:
                    numero = "UM";
                    break;

                case 2:
                    numero = "DOIS";
                    break;

                case 3:
                    numero = "TRÊS";
                    break;

                default:
                    Console.WriteLine("CODIGO INVALIDO LEMBRE-SE (1) (2) OU (3)");
                    return;

            }
            Console.WriteLine("VOCÊ DIGITOU O NUMERO " + numero);

            Console.ReadLine();
        }
    }
}
