﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oat_3_exercicio_53
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("VAI INCLUIR QUANTOS NUMEROS ? ");
            int n = int.Parse(Console.ReadLine());

            int[] numeros = new int[n];

            for (int cont = 0; cont < n; cont++)
            {
                Console.Write("ENTRE COM O VALOR NA " + (cont + 1) + "° POSIÇAO: ");
                numeros[cont] = int.Parse(Console.ReadLine());

            }

            for (int c = (n - 1); c >= 0; c--)
            {
                Console.WriteLine("O NUMERO OCUPA O " + (c + 1) + "° POSICAO E O " + numeros[c]);
            }

            Console.ReadLine();
        }
    }
}
